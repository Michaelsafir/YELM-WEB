# YELM-WEB ![](https://img.shields.io/badge/version-v2.0-green)

---
 Create powerfull WEB Engine for 

 *Here will be web part of our service. We look to be OpenSource, so everyone can publish own applications based on our SwiftUI code.*

![](./demo_new.gif)

---
*We create simple engine to show retail markets in AppStore and easy change it on web. I share some demo code of platform to hear about bugs and other problems occured in code..*